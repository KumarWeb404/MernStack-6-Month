module.exports = [
  {
    id: 0,
    name: 'top',
    category: 'Women',
    price: 500,
  },
  {
    id: 1,
    name: 'LEGO Classic Creative Brick Box',
    category: 'Kids',
    price: 450,
  },
  {
    id: 2,
    name: 'Crayola Inspiration Art Case',
    category: 'Kids',
    price: 700,
  },
  {
    id: 3,
    name: 'Melissa & Doug Wooden Building Blocks Set',
    category: 'Kids',
    price: 1000,
  },

  {
    id: 4,
    name: 'Fisher-Price Laugh & Learn Smart Stages Chair',
    category: 'Kids',
    price: 500,
  },
  {
    id: 5,
    name: 'VTech Kidizoom Smartwatch DX2',
    category: 'Kids',
    price: 2000,
  },

  {
    id: 6,
    name: "L'Oreal Paris Infallible Pro-Matte Liquid Lipstick",
    category: 'Women',
    price: 799,
  },
  {
    id: 7,
    name: "Levi's Women's Classic Bootcut Jeans",
    category: 'Women',
    price: 2499,
  },
  {
    id: 8,
    name: "Nike Women's Revolution 5 Running Shoes",
    category: 'Women',
    price: 3499,
  },
  {
    id: 9,
    name: 'Maybelline New York Fit Me Matte + Poreless Foundation',
    category: 'Women',
    price: 549,
  },
  {
    id: 10,
    name: "Allen Solly Men's Solid Regular Fit Polo",
    category: 'Men',
    price: 999,
  },
  {
    id: 11,
    name: "Fossil Men's Grant Stainless Steel Chronograph Watch",
    category: 'Men',
    price: 7999,
  },
  {
    id: 12,
    name: "Adidas Men's Own The Run Running Shorts",
    category: 'Men',
    price: 1499,
  },
  {
    id: 13,
    name: "Philips Norelco Multigroom Series 7000 Men's Grooming Kit",
    category: 'Men',
    price: 3999,
  },
  {
    id: 14,
    name: "Men's Grooming Kit",
    category: 'Men',
    price: 1999,
  },
];
