const students = [
  {
    id: 1,
    name: 'Rahul',
    course: 'MERN',
  },
  {
    id: 2,
    name: 'Rithik',
    course: 'MERN',
  },
  {
    id: 3,
    name: 'Ajay',
    course: 'MERN',
  },
  {
    id: 4,
    name: 'Tanveer',
    course: 'MEAN',
  },
  {
    id: 5,
    name: 'Gaurav',
    course: 'MEAN',
  },
  {
    id: 6,
    name: 'Akashdeep',
    course: 'MEAN',
  },
  {
    id: 7,
    name: 'Vishal',
    course: 'MEAN',
  },
  {
    id: 8,
    name: 'Rajneesh',
    course: 'MEAN',
  },
];

module.exports = students;
